# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['az_cli_snowflake', 'az_cli_snowflake.connectors']

package_data = \
{'': ['*'], 'az_cli_snowflake': ['queries/*']}

install_requires = \
['azure-cli>=2.43.0,<3.0.0',
 'pandas>=1.5.2,<2.0.0',
 'pyOpenSSL>=22.0.0',
 'pyarrow==8.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'snowflake-connector-python>=2.9.0,<3.0.0',
 'snowflake-snowpark-python>=1.0.0,<2.0.0',
 'tqdm>=4.64.1,<5.0.0']

setup_kwargs = {
    'name': 'az-cli-snowflake',
    'version': '0.1.0',
    'description': 'Communicate between azure cli and snowflake to manage and store azure information from Snowflake',
    'long_description': None,
    'author': 'sebastian hansen',
    'author_email': 'sebastian.hansen@dataalchemy.dev',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<3.9.0',
}


setup(**setup_kwargs)

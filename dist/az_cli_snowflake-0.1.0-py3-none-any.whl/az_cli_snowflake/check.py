from config import *
import os
import os
print(os.getenv('lll_service_principal'))

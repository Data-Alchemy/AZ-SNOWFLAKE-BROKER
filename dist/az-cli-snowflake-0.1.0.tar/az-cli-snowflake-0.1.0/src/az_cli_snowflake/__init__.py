import sys
__version__ = '0.1.0'

sys.path.insert(0, './src/az_cli_snowflake/connectors')
sys.path.insert(1, './src/az_cli_snowflake')